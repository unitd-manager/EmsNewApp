export default {
  userDark: require('../images/userDark.png'),
  userLight: require('../images/userLight.png'),
  getStarted: require('../images/getStarted.png'),
  User: require('../images/menu/User.png'),
};
