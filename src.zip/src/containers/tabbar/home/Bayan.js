import React from 'react';
import { Text} from 'react-native';


const AudioFiles = () => {
    return (
        <>
            <Text>Bayan</Text>
        </>
    )
}
export default AudioFiles;